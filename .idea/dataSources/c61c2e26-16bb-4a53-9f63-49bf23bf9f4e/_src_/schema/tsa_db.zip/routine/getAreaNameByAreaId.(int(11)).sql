CREATE FUNCTION getAreaNameByAreaId(AREA_ID INT)
  RETURNS VARCHAR(128)
  BEGIN
	DECLARE area_name VARCHAR(128) DEFAULT NULL;
	select a.name into area_name from base_area_info a where a.id = area_id;
	RETURN area_name;
END;
