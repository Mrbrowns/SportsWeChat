CREATE FUNCTION getAreaFullNameByAreaId(AREA_ID INT)
  RETURNS VARCHAR(128)
  BEGIN
	DECLARE area_name VARCHAR(128) DEFAULT NULL;
	DECLARE full_arae_name VARCHAR(128) DEFAULT NULL;
	SET full_arae_name =  '';
	
	area_loop: LOOP
		select a.name, a.p_id into area_name, AREA_ID from base_area_info a where a.area_id = AREA_ID;
		set full_arae_name = CONCAT(area_name, full_arae_name);
		
		IF AREA_ID = 0 THEN
		 LEAVE  area_loop;
		END IF;
	END LOOP;
	RETURN full_arae_name;
END;
